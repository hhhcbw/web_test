#include "serialPort.hpp"
#include <iostream>
char buff[512];
const char *dev = "/dev/ttyUSB0";
int main()
{ serialPort myserial;
  int i,nread,nwrite;
  cout<<"serialPort Test"<<endl;
  myserial.OpenPort(dev);
  myserial.setup(9600,0,8,1,'N'); 
  while (true)
  {
	  nread = myserial.readBuffer( buff,20);
          // printf("%d\n",nread);
	  printf("%.*s",nread,buff);
          fflush(stdout);
          usleep(2000); 
 }
}
